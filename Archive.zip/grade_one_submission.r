# load in the package
library(gradeR)

calcGradesForGradescope("Lesson_1_Assignment_Introduction_to_R_Part_1.R",       # each student's submission must be named this!
                        "Lesson_1_Assignment_Tests.R") # the file with all of the testthat tests 
  
